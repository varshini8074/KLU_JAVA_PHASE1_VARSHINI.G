import java.util.*;
class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        if(a>=0 && a <= 34)
        System.out.print("Fail");
        else if(a >= 35 && a <=60)
        System.out.print("Average");
        else if(a >= 61 && a<=80)
        System.out.print("Good");
        else if(a >= 81 && a <= 100)
        System.out.print("Excellent");
        else 
        System.out.print("Invalid");
    }
}