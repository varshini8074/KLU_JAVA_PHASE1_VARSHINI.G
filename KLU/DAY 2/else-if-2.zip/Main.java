import java.util.*;
class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int c = sc.nextInt();
        if(a == b && b == c) {
            System.out.print("Equilateral triangle");
        else if(a>b && b <= c)
            System.out.print("Isosceles triangle");
        else 
            System.out.print("Scalene triangle");
        }
    }
}