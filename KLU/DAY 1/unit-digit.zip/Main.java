import java.util.*;
class Main {
    public static void main(String[] args) {
        Scanner obj = new Scanner(System.in);
        int a = obj.nextInt();
        System.out.printf("UNIT DIGITS :" + a /10);
    }
}