import java.util.*;
class Main{
    public static void main(String[] args) {
        ArrayList <Integer> obj = new ArrayList<Integer>();
        Scanner s = new Scanner(System.in);
        int n = s.nextInt();
        for(int i = 0;i<n;i++) 
        obj.add(s.nextInt());
        System.out.println(obj);
        obj.add(4,2);
        System.out.println(obj);
        obj.add(50);
        System.out.println(obj);
        System.out.println(obj.get(1));
        System.out.println(obj.contains(20));
        obj.clear();
        System.out.println(obj);
    }
}